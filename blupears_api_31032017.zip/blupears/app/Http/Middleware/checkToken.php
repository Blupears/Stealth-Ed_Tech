<?php

namespace App\Http\Middleware;

use Closure;
use App\Model\Token;
use App\Helper\ApiHelper;

class checkToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @review done
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Check token is empty or not
        if(!$request->has('token')){
            $response = [
                'code'      => getenv('REQUIRED_TOKEN_CODE'),
                'message'   => getenv('REQUIRED_TOKEN_MESSAGE'),
                'responseText' => ""
            ];
            ApiHelper::writeLog(request(), $response, 'userResource');
            return response()->json($response);
        }

        // Check hiremee_id is emprt or not
        if(!$request->has('user_id')){
            $response = [
                'code'      => getenv('REQUIRED_USER_ID_CODE'),
                'message'   => getenv('REQUIRED_USER_ID_MESSAGE'),
                'responseText' => ""
            ];
            ApiHelper::writeLog(request(), $response, 'userResource');
            return response()->json($response);
        }

        // check token and hiremee_id
        $checkLoginToken = Token::where('token', $request->token);

        if($request->has('user_id')){
            $checkLoginToken = $checkLoginToken->where('user_id',$request->user_id);
        }
        $checkLoginToken = $checkLoginToken->first();
        if(!$checkLoginToken){
            $response = [
                'code'      => '501',//getenv('INVALID_TOKEN_CODE'),
                'message'   => 'INVALID_TOKEN',//getenv('INVALID_TOKEN_MESSAGE'),
                //'query'     => $checkLoginToken,
                'responseText' => ""
            ];
            ApiHelper::writeLog(request(), $response, 'userResource');
            return response()->json($response);
        }

        // check token and user_id with check token is expire or not
        $checkTokenExpire = Token::where('token', $request->token)
                ->where('token_expiry','>',date('Y-m-d H:i:s'))
                ->first();
        
        // Check it is null or not
        if(is_null($checkTokenExpire)){
            $response = [
                'code'      => '502',//getenv('EXPIRY_TOKEN_CODE'),
                'message'   => 'EXPIRY_TOKEN',//getenv('EXPIRY_TOKEN_MESSAGE'),
               // 'query'     => $checkTokenExpire,
                'responseText' => ""
            ];
            ApiHelper::writeLog(request(), $response, 'userResource');
            return response()->json($response);
        }

        return $next($request);
    }
}
