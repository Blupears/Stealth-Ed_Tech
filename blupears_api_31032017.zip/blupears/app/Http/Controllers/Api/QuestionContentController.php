<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\QuestionContent;
use App\Helper\ApiHelper;

class QuestionContentController extends Controller
{
   
     public function __construct ()
        {
            $this->question_content = new QuestionContent();

        }


     public function getdata(Request $request)
    {
           $question_content_data=$request->all();

            $question_content_data=$question_content_data['question_content_group_id'];
              $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'QuestionContentcontentgroup');
                return response()->json($response);
            }   
             $result=$this->question_content->getvalue($question_content_data);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('CHARACTER_ERROR_CODE'),
                    'message'   => 'character is not there for corresponding character id'
                ];
                ApiHelper::writeLog(request(), $response, 'QuestionContentcontentgroup');
                return response()->json($response);
            }  

 return response()->json($result);
          
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('question_content_group_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'Question content group id misssing'
            ];
        }
        return true;
    }


}
