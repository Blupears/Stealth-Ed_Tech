<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Login;
use App\Helper\ApiHelper;
use Illuminate\Support\Facades\Hash;
use App\Model\Token;

class LoginController extends Controller
{
     public function __construct()
    {
    	  $this->loginObj = new login();

    } 
    	public function login(Request $request)
    	{

    		$strLogin=$request->all();

    		$email=$strLogin['email'];
    		$password=$strLogin['password'];


    		// Check parameters
	       $response = $this->validateParameters();
 
	        if($response !== true){
	            ApiHelper::writeLog(request(), $response,'login');
	            return response()->json($response);
	        }	
 
            $result=$this->loginObj->validateUser($email);

             
				   if(!$result){
				            $response = [
				                'code'      => getenv('LOGIN_ERROR_CODE'),
				                'message'   => 'Invalid email or account is not active'
				            ];
				            ApiHelper::writeLog(request(), $response, 'login');
				            return response()->json($response);
				        } else {
				            if (!Hash::check(request()->input('password'), $result->PASSWORD))
				            {
				                $response = [
				                'code'      => getenv('LOGIN_ERROR_CODE'),
				                'message'   => 'Invalid email or password'
				                ];
				                ApiHelper::writeLog(request(), $response, 'login');
				                return response()->json($response);
				            }
				        }
             $user_id = $result->USER_ID;

			  $token = $this->insertToken($user_id);
		        $response   = [
		            'code'      => getenv('LOGIN_SUCCESS_CODE'),
		            'message'   => getenv('LOGIN_SUCCESS_MSG'),
		            'token'     => $token->token,
		            'expire'    => $token->token_expiry,
		            'user_type' => 'L',
		            'user_id'=> $user_id
		        ];
		                        
		        ApiHelper::writeLog(request(), $response, 'login');
 		        return response()->json($response);	        				
   	}

/**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('email')){
            return [
                'code'      => getenv('LOGIN_ERROR_CODE'),
                'message'   => 'Missing email address'
            ];
        }
        if(!request()->has('password')){
            return [
                'code'      => getenv('LOGIN_ERROR_CODE'),
                'message'   => 'Missing password'
            ];
        }
                
        return true;
    }


    	/**
     * insertToken
     * @param type $device_id
     * @param type $hiremee_id
     * @return type
     */
    protected function insertToken($user_id)
    {

        $token = Token::createToken('L');
        $tokenExpire = Token::getTokenTimeoutTimestamp();

        return Token::create([
            'token_type'    => 'L',
            'token'         => $token,
            'token_expiry'  => date('Y-m-d H:i:s',$tokenExpire),
            'token_expiry_secs' => getenv('TOKEN_TIMEOUT'),
            'user_id'=> $user_id
        ]);
    }

 
}
