<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\CharacterType;
use App\Helper\ApiHelper;

class CharacterTypeController extends Controller
{
   
     public function __construct ()
        {
            $this->character_obj = new CharacterType();

        }


     public function getdata(Request $request)
    {
           $character_data=$request->all();

            $character_data=$character_data['character_id'];
              $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'character');
                return response()->json($response);
            }   
             $result=$this->character_obj->getvalue($character_data);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('CHARACTER_ERROR_CODE'),
                    'message'   => 'character is not there for corresponding character id'
                ];
                ApiHelper::writeLog(request(), $response, 'character');
                return response()->json($response);
            }  

 return response()->json($result);
          
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('character_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'character type id misssing'
            ];
        }
        return true;
    }


}
