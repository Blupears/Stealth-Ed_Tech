<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Question;
use App\Helper\ApiHelper;

class QuestionController extends Controller
{
   
     public function __construct ()
        {
            $this->question = new Question();

        }


     public function getdata(Request $request)
    {
           $question_data=$request->all();

            $question_data=$question_data['question_content_group_id'];
              $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'Question');
                return response()->json($response);
            }   
             $result=$this->question->getvalue($question_data);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('CHARACTER_ERROR_CODE'),
                    'message'   => 'Question is not there for corresponding question content group id'
                ];
                ApiHelper::writeLog(request(), $response, 'Question');
                return response()->json($response);
            }  

 return response()->json($result);
          
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('question_content_group_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'Question content group id misssing'
            ];
        }
        return true;
    }


}
