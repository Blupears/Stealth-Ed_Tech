<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Location;
use App\Helper\ApiHelper;

class LocationController extends Controller
{
    //
     public function __construct ()
	    {
	    	$this->location_obj = new Location();

	    }


     public function getdata(Request $request)
    {
           $location_data=$request->all();

            $location_data=$location_data['location_id'];
              $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'location');
                return response()->json($response);
            }   
             $result=$this->location_obj->getvalue($location_data);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('LOCATION_ERROR_CODE'),
                    'message'   => 'location is not there for corresponding location id'
                ];
                ApiHelper::writeLog(request(), $response, 'location');
                return response()->json($response);
            }  

 return response()->json($result);
    	  
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('location_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'Missing  location id'
            ];
        }
        return true;
    }


}
