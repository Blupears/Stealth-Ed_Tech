<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Character;
use App\Helper\ApiHelper;

class CharacterController extends Controller
{
   
     public function __construct ()
        {
            $this->character_obj = new Character();

        }


     public function getdata(Request $request)
    {
           $character_data=$request->all();

            $character_type_id=$character_data['character_type_id'];
            $location_type_id=$character_data['location_type_id'];

              $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'charactertype');
                return response()->json($response);
            }   
             $result['character']=$this->character_obj->getvalue($character_type_id,$location_type_id);
             $result['story']=$this->character_obj->getstoryvalue($location_type_id);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('CHARACTER_ERROR_CODE'),
                    'message'   => 'character is not there for corresponding 
                                    character id or character type     id '
                ];
                ApiHelper::writeLog(request(), $response, 'charactertype');
                return response()->json($response);
            }  

 return response()->json($result);
          
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('character_type_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'character type id misssing'
            ];
        }elseif(!request()->has('location_type_id'))
        {
          return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'character type id misssing'
            ];

        }
        return true;
    }


}
