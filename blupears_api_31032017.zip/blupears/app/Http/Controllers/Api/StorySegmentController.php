<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\StorySegment;
use App\Helper\ApiHelper;

class StorySegmentController extends Controller
{
   
     public function __construct ()
        {
            $this->story_segment = new StorySegment();

        }


     public function getdata(Request $request)
    {
          $story_data=$request->all();

          $story_data=$story_data['story_id'];
          $response = $this->validateParameters();

            if($response !== true){
                ApiHelper::writeLog(request(), $response,'Story');
                return response()->json($response);
            }   
             $result=$this->story_segment->getvalue($story_data);


            if(!$result)
            {
                $response = [
                    'code'      => getenv('CHARACTER_ERROR_CODE'),
                    'message'   => 'story is not there for corresponding story id'
                ];
                ApiHelper::writeLog(request(), $response, 'Story');
                return response()->json($response);
            }  

 return response()->json($result);
          
    }


    /**
     * Validate parameters
     * @return type
     */
    protected function validateParameters()
    {
        if(!request()->has('story_id')){
            return [
                'code'      => getenv('LOCATION_ERROR_CODE'),
                'message'   => 'Story id misssing'
            ];
        }
        return true;
    }


}
