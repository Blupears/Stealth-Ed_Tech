<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\register;

use DB;

class RegisterController extends Controller
{
       public function __construct()
        {
            $this->register = new register();
        }

    public function createuser(Request $request)
    {

        $strCreate=$request->all();
        
        $data=array(
                   
                    'dateofbirth'=>$strCreate['dateofbirth'],
                    'gender'=>$strCreate['gender'],
                    'email'=>$strCreate['email'],
                    'phone_number'=>$strCreate['phone_number'],
                    'login_name'=>$strCreate['login_name'],
                    'password'=>bcrypt($strCreate['password']),
                    'status'=>$strCreate['status']
                    );
 
            $result=$this->register->createdb($data);
 
            if(!is_null($result))
            {
                  $response = [
                                'code'      => getenv('REGIST_SUCCESS_CODE'),
                                'message'   => getenv('REGIST_SUCCESS_MSG'),
                            ];
            }
            else
            {
                 $response = [
                            'code'      => getenv('REGIST_ERROR_CODE'),
                            'message'   => getenv('REGIST_ERROR_MSG'),
                            ];
             }
            
            return response()->json($response);
    }
     

}





