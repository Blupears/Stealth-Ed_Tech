<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class login extends Model
{
    //

    protected $table='users';

    public function validateUser($email)
    {
		return static::where('EMAIL',$email)->first();
	}
   
}
