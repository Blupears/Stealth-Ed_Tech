<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class CharacterType extends Model
{
	 protected $table="character_type_table";

	 public function getvalue($character_id)
	 {
	 	 
	 	return static::where('CHARACTER_TYPE_ID',$character_id)->first();

	 }

}
