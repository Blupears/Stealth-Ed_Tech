<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Location extends Model
{
	 protected $table="location_type_table";

	 public function getvalue($location_id)
	 {
	 	 
	 	return static::where('LOCATION_TYPE_ID',$location_id)->first();
	 }

}
