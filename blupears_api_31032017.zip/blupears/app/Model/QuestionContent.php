<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class QuestionContent extends Model
{
	 protected $table="question_content_group_table";

	 public function getvalue($question_content_group_id)
	 {
	 	 
 	 	return DB::table('question_content_group_table')->get();
	 }

}
