<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Question extends Model
{
	 protected $table="question_table";

	 public function getvalue($question_content_group_id)
	 {
	 	return static::where('QUESTION_CONTENT_GROUP_ID',$question_content_group_id)->get();
 	 }

}
