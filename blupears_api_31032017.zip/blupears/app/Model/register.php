<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class register extends Model
{
	 protected $table="users";

    public $fillable=[
					"DATEOFBIRTH",
					"GENDER",
					"EMAIL",
					"PHONE_NUMBER",
					"LOGIN_NAME",
					"PASSWORD",
					'STATUS'
    			 ];
    			 
	 public function createdb($data)
	 {
	 	return static::insert($data,$this->fillable);
	 	 
	 }

}
