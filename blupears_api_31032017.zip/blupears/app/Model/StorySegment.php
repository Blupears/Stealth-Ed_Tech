<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class StorySegment extends Model
{
	 protected $table="segment_table";

	 public function getvalue($story_id)
	 {
	 	return static::where('STORY_ID',$story_id)->get();
	 }

}
