<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Helper\ApiHelper;

class Token extends Model
{
    protected $table = "token";
    
    protected $guarded = ["id"];

    public function insertToken($device_id, $hiremee_id)
    {
        $token = static::createToken('L');
        $tokenExpire = static::getTokenTimeoutTimestamp();
        


        return static::create([
            'token_type'    => 'L',
            'token'         => $token,
            'token_expiry'  => date('Y-m-d H:i:s',$tokenExpire),
            'token_expiry_secs' => getenv('TOKEN_TIMEOUT'),
            'device_id'     => $device_id,
            'hiremee_id'    =>''
        ]);
    }
    
    public function insertwebtoken($id)
    {
       $token = static::createToken('W');
       $tokenExpire = static::getTokenTimeoutTimestamp();

         return static::create([
            'token_type'    => 'W',
            'token'         => $token,
            'token_expiry'  => date('Y-m-d H:i:s',$tokenExpire),
            'token_expiry_secs' => getenv('TOKEN_TIMEOUT'),
            'hiremee_id'    => $id
        ]);

    }


    public static function createToken($type='R')
    {
        // Generate token
        $randomString = ApiHelper::generateRandomString(16);
        $prefix = $type. getenv('TOKEN_UID');
        return $prefix.$randomString;
    }
    
    public static function getTokenTimeoutTimestamp()
    {
        return strtotime('+ '. getenv('TOKEN_TIMEOUT') . ' mins');
    }

    public function regeneratetoken($token,$hiremee_id)
    {
       
        $data = static::where("token",$token)
                    ->where("hiremee_id",$hiremee_id)
                    ->first();

        $tokenExpire = $this->getTokenTimeoutTimestamp();
        
        $randomString = ApiHelper::generateRandomString(16);
        $prefix = $data->token_type. getenv('TOKEN_UID');
        $retoken = $prefix.$randomString;

        static::where("id",$data->id)->update(['token'=>$retoken,'token_expiry'=>date('Y-m-d H:i:s',$tokenExpire)]);

        $data = ['token'=>$retoken,'expire'=>date('Y-m-d H:i:s',$tokenExpire),'hiremee_id'=>$hiremee_id];



        return $data;
    }

     public function regeneratewebtoken($token,$hiremee_id)
    {
        $data = static::where("token",$token)
                    ->where("hiremee_id",$hiremee_id)
                    ->first();

        $tokenExpire = $this->getTokenTimeoutTimestamp();
        
        $randomString = ApiHelper::generateRandomString(16);
        $prefix = $data->token_type. getenv('TOKEN_UID');
        $retoken = $prefix.$randomString;

        static::where("id",$data->id)->update(['token'=>$retoken,'token_expiry'=>date('Y-m-d H:i:s',$tokenExpire)]);

        $data = ['token'=>$retoken,'expiry'=>date('Y-m-d H:i:s',$tokenExpire),'id'=>$hiremee_id];



        return $data;
    }


    public function getTokenDetail($token,$hiremee_id)
    {
        return static::where("token",$token)
                    ->where("hiremee_id",$hiremee_id)
                    ->first();
    }
}

