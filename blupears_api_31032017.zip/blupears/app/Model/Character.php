<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Character extends Model
{
	 protected $table="character_table";

	 public function getvalue($character_type_id,$location_type_id)
	 {
	 	 
	 	return static::where('CHARACTER_TYPE_ID',$character_type_id)
					  ->where('LOCATION_TYPE_ID',$location_type_id)
	 				  ->get(); 
	 }
	public function getstoryvalue($location_type_id)
	{
		  return $result =  DB::table('story_table')->where('LOCATION_TYPE_ID',$location_type_id)
		  				->get();
	}
}
