<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Helper;

class ApiHelper
{
   
    public static function writeLog($request,$response,$type)
    {
        if($request->has('token'))
        {
         
            $tokenData = null;
            if(!empty($request->input('token'))){    
                $tokenData = \App\Model\Token::where("token",$request->input('token'))->first();
            }
            if(!is_null($tokenData)){
                $token_id = $tokenData->id;
            }else{
                $token_id = '0';
            }
        }
        else{
                $token_id = '0';    
            }

       

        \App\Model\Auditlog::create([
            'token_id'=> $token_id,
            'api'       => $type,
            'request'   => json_encode($request->all()),
            'response'  => json_encode($response),
            'ip_address'  => $request->ip(),
            'code'      => $response['code'],
            'msg'       => json_encode($response['message']),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
    
     
    
    /**
     * Extract keys from array
     * @param type $data
     * @param type $keys
     * @return type
     */
    

    public static function generateRandomString($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
    {
        $str = '';
        $max = mb_strlen($keyspace, '8bit') - 1;
        for ($i = 0; $i < $length; ++$i) {
            $str .= $keyspace[random_int(0, $max)];
        }
        return $str;
    }

    
}


